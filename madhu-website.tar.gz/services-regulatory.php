<!DOCTYPE html>
<!--[if IE 7]>                  <html class="ie7 no-js" lang="en">     <![endif]-->
<!--[if lte IE 8]>              <html class="ie8 no-js" lang="en">     <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html class="not-ie no-js" lang="en">
<!--<![endif]-->
<head>
<!-- Basic Page Needs
	================================================== -->
<meta charset="utf-8">
<title>Services - Dossier Solutions and Services LLP</title>
<link rel="icon" href="images/logo1.png"><meta name="description" content="">
<meta name="description" content="">
<meta name="author" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<!-- Mobile Specific Metas
	================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!-- CSS
	================================================== -->
<!-- Normalize default styles -->
<link rel="stylesheet" href="css/normalize.css" media="screen" />
<!-- Skeleton grid system -->
<link rel="stylesheet" href="css/skeleton.css" media="screen" />
<!-- Base Template Styles-->
<link rel="stylesheet" href="css/base.css" media="screen" />
<!-- Template Styles-->
<link rel="stylesheet" href="css/style.css" media="screen" />
<!-- Superfish -->
<link rel="stylesheet" href="css/superfish.css" media="screen" />
<!-- Prettyphoto -->
<link rel="stylesheet" href="css/prettyPhoto.css" media="screen" />
<!-- FontAwesome -->
<link rel="stylesheet" href="css/font-awesome.min.css" media="screen" />
<!-- REVOLUTION BANNER CSS SETTINGS -->
<link rel="stylesheet" href="css/settings.css" media="screen" />
<!-- Flexslider -->
<link rel="stylesheet" href="css/flexslider.css" media="screen" />
<!-- Layout and Media queries-->
<link rel="stylesheet" href="css/media-queries.css" media="screen" />
<!--[if lt IE 9]>
		<link rel="stylesheet" href="css/ie/ie8.css" media="screen" />
	<![endif]-->
<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
<!-- Favicons
	================================================== -->
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/apple-touch-icon-144x144.png">
<script language="JavaScript">
<!--
function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
    } if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
} }

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<body>
<!-- BEGIN WRAPPER -->
<div id="wrapper">
<div class="wrapp-holder">
<div class="wrap-frame">
<!-- BEGIN HEADER -->
<header id="header" class="header">
  <!-- Top Header -->
  <div class="header-top">
    <div class="container clearfix">
      <div class="grid_12">
        <!-- Top Menu -->
        <ul class="header-top-menu unstyled">
          <span style="color:#ebebeb">Top notch solutions, delivered on time every time!!</span>
          <!--<li><a href="#">Pricing</a></li>
									<li><a href="#">Sitemap</a></li>
									<li><a href="#">FAQs</a></li>-->
        </ul>
        <!-- /Top Menu -->
        <!-- Social Links -->
        <ul class="social-links unstyled">
          <script type="text/javascript">

// Current Server Time script (SSI or PHP)- By JavaScriptKit.com (http://www.javascriptkit.com)
// For this and over 400+ free scripts, visit JavaScript Kit- http://www.javascriptkit.com/
// This notice must stay intact for use.

//Depending on whether your page supports SSI (.shtml) or PHP (.php), UNCOMMENT the line below your page supports and COMMENT the one it does not:
//Default is SSI method is uncommented:

//var currenttime = '<!--#config timefmt="%B %d, %Y %H:%M:%S"--><!--#echo var="DATE_LOCAL" -->' //SSI method of getting server date
//var currenttime = 'May 30, 2021 00:20:14' //PHP method of getting server date
var currenttime = 'May 30, 2021 00:20:14' //PHP method of getting server date

///////////Stop editting here/////////////////////////////////

var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
var serverdate=new Date(currenttime)

function padlength(what){
var output=(what.toString().length==1)? "0"+what : what
return output
}

function displaytime(){
serverdate.setSeconds(serverdate.getSeconds()+1)
var datestring=montharray[serverdate.getMonth()]+" "+padlength(serverdate.getDate())+", "+serverdate.getFullYear()
var timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())+":"+padlength(serverdate.getSeconds())
document.getElementById("servertime").innerHTML=datestring
}

window.onload=function(){
setInterval("displaytime()", 1000)
}


</script>
      <span id="servertime" style="color:#ebebeb"></span>
        </ul>
        <!-- /Social Links -->
      </div>
    </div>
  </div>
  <!-- /Top Header -->
  <!-- Main Header -->
  <div class="header-main">
    <div class="container clearfix">
      <div class="grid_12 hr-bottom">
        <!-- BEGIN LOGO -->
        <div id="logo">
          <!-- Image based Logo-->
          <a href="index.php"><img src="images/logo.png" alt="Dossier Solutions & Services LLP" width="325" /></a>
          <!-- Text based Logo
									<h1><a href="index.html">Emotion</a></h1>
									<p class="tagline">Responsive HTML Template</p>
									-->
        </div>
        <!-- END LOGO -->
        <!-- BEGIN NAVIGATION -->
        <nav class="primary">
          <ul class="sf-menu">
            <li > <a href="index.php">Home<!--<span><i>|</i> Get Started</span>--></a> </li>
            <li > <a href="aboutus.php">About Us<!--<span><i>|</i> Why Choose Us</span>--></a></li>
            <li class="current-menu-item"> <a href="services.php">Services<!--<span><i>|</i>Regulatory & Support</span>--></a>
            <!-- Sub Navigation -->
              <ul>
                <li><a href="services-regulatory.php">Regulatory Services</a></li>
                <li><a href="services-support.php">Support Services</a></li>
              </ul>
              <!-- /Sub Navigation -->
              </li>
               <li > <a href="team.php">Team<!--<span><i>|</i> Get in Touch</span>--></a>
            </li>
             <li > <a href="careers.php">Careers<!--<span><i>|</i> Get in Touch</span>--></a>
            </li>
             <li > <a href="enquiry.php">Enquiry<!--<span><i>|</i> Get in Touch</span>--></a>
            </li>
            <li > <a href="contactus.php">Contact<!--<span><i>|</i> Get in Touch</span>--></a>
            </li>
          </ul>
        </nav>
        <!-- END NAVIGATION -->
      </div>
    </div>
  </div>
  <!-- /Main Header -->
</header>
<!-- END HEADER -->
      <!-- BEGIN CONTENT WRAPPER -->
      <div id="content-wrapper" class="content-wrapper">
        <div class="container maincontent">
      <!-- BEGIN SLIDER -->
      <div id="slider" class="slider loading" style="height:150px; padding-top:15px;">
        <div class="container clearfix">
          <!--<div class="grid_12">-->
            <div class="bannercontainer" style="height:150px;">
              <div class="banner">
                <ul>
                <!-- THE FIRST SLIDE -->
                  <li data-transition="fade" data-slotamount="10" data-masterspeed="300" data-slideindex="back">
                    <!-- THE MAIN IMAGE IN THE SLIDE -->
                    <img src="images/bg-01.jpg" style="margin-top:-130px;">
                    <!-- THE CAPTIONS OF THE FIRST SLIDE -->
                    <div class="tp-caption sfl original"
												data-x="50"
												data-y="25"
												data-speed="300"
												data-start="600"
												data-captionhidden="on"
												data-endeasing="easeOutExpo"
												data-easing="easeOutExpo"> Top Notch Solutions </div>
                    <div class="tp-caption sfr original_high"
												data-x="100"
												data-y="78"
												data-speed="300"
												data-start="800"
												data-captionhidden="on"
												data-endeasing="easeOutExpo"
												data-easing="easeOutExpo"> Delivered on time every time! </div>
                  </li>
                </ul>
              </div>
            </div>
         <!-- </div>-->
        </div>
      </div>
      <!-- END SLIDER -->
      <!-- BEGIN PAGE TITLE -->
      <div id="page-title" class="page-title">
        <!--<div class="container clearfix maincontent">-->
          <div class="grid_12">
            <div class="page-title-holder clearfix">
              <h1>SERVICES</h1>
            </div>
          </div>
        <!--</div>-->
      </div>
      <!-- END PAGE TITLE -->

          <div class="clearfix">
            <div class="grid_9">
              <h2>REGULATORY SERVICES</h2>
              <!-- BEGIN ACCORDION WRAPPER -->
              <dl class="accordion-wrapper">
                <dt class="acc-head active"> <a href="#">Dossier creation</a> </dt>
                <dd class="acc-body">
                  <div class="content">
                    <p>We write dossiers that meet all national    and international requirements and is in accordance with all legal demands.</p>
                    <ul>
                      <li>Dossier in CTD (modules    1 &ndash; 5 or any requisite module) and eCTD formats for worldwide markets like    EU, USA, UK,</li>
                      <li>Preclinical and clinical    Overviews / Summary writing&nbsp; based on    literature search / Published studies / articles from journals .</li>
                      <li>Dossiers for ASEAN and    ROW countries in ACTD/ &nbsp;as per country    specific format, for any dosage form.</li>
                      <li>Dossier reformatting to    CTD / eCTD by taking up gap analysis of existing dossiers in line with    current requirements.</li>
                      <li>Product information    update (SmPC, PIL and Labeling). </li>
                      <li>Preparation  of Drug Master File and Certificate of suitability (open and closed part) </li>
                    </ul>
                  </div>
                </dd>
                <!-- //.acc-body -->
                <dt class="acc-head"> <a href="#">Dossier review and maintenance</a> </dt>
                <dd class="acc-body">
                  <div class="content">
                    <ul>
                      <li>Our counterparts in    Europe take up review of dossiers prepared for registration in EU/UK.&nbsp; </li>
                      <li>We will evaluate your    technical data through all stages of the development process, review study    protocols and conduct due diligence on your behalf.</li>
                      <li>Provide EU-QP services    for Pre-clinical and Clinical modules.</li>
                      <li>Handling  of all types of variations (Type Ia, Ib and II), annual reports, renewals of  MAAs and support in query responses.</li>
                    </ul>
                  </div>
                </dd>
                <!-- //.acc-body -->
                <dt class="acc-head"> <a href="#">Translation services</a> </dt>
                <dd class="acc-body">
                  <div class="content">
                    <p>Translation of dossiers, SmPC, PIL, Packaging, Labeling & inserts, CRFs, clinical trial protocol & report etc to 60 + languages; viz European, Russian, ASEAN etc.</p>
                  </div>
                </dd>
                <!-- //.acc-body -->
                <dt class="acc-head"> <a href="#">Product Literature & Readability Testing</a> </dt>
                <dd class="acc-body">
                  <div class="content">
                    <p><strong>SPC/SmPC, PIL and Labeling Texts</strong><br>
                      We advise on the regulatory requirements for both content and format under legislation as well as write or review the relevant texts.</p>
                    <p> Writing services for Summaries of Product Characteristics, Patient Information Leaflets and labeling texts. These documents can be created from scratch or existing texts can be updated to reflect changes in the registered details or to improve readability.</p>
                    <p>Alternatively, we assess clients&rsquo; own product literature, and advise on the medical and scientific accuracy of the statements as well as checking for compliance with the registered details, the legal requirements, applicable guidelines and standard terms.</p>
                    <p><strong>Readability Testing</strong><br>
                      Our counterparts in EU who have a panel of volunteers on whom the testing is carried out as per Article 59 (3) of Directive 2001/83/EC and customer specific requirements.</p>
                  </div>
                </dd>
                <!-- //.acc-body -->
                <dt class="acc-head"> <a href="#">Artwork designing</a> </dt>
                <dd class="acc-body">
                  <div class="content">
                    <p>Our experienced packaging designer will support    you in the packaging development. We can manage your entire artwork    system, from creation through to post-licensing maintenance and packager    liaison.</p>
                    <p>Colour mock-ups of the leaflet and labels, meeting all  the applicable guidelines and suitable for submission to regulatory  authorities, can be provided</p>
                    <p>Artwork is provided as PDF files suitable for electronic submission.</p>
                  </div>
                </dd>
                <!-- //.acc-body -->
                <dt class="acc-head"> <a href="#">GMP documentation</a> </dt>
                <dd class="acc-body">
                  <div class="content">
                    <ul>
                      <li>Writing of QA, QC, Production, R&amp;D and&nbsp; Corporate QA SOP&rsquo;s</li>
                      <li>Review and revision of existing SOP&rsquo;s</li>
                      <li>Audit to identify need for new SOP&rsquo;s and prepare new SOP&rsquo;s</li>
                      <li>Preparation and review of packaging material and raw    material specifications</li>
                      <li>Preparation of quality manual and Policy for the company</li>
                      <li>Preparation of Safety, health and environment related    SOP&rsquo;s </li>
                      <li>Review existing MFR&rsquo;s and revise to meet regulatory    requirements</li>
                      <li>Preparation of annual product review and trend analysis</li>
                      <li>Preparation and revision of Site Master File</li>
                      <li>Preparation and revision of Validation master Plan</li>
                      <li>Review and revision of protocols for various types of    validations
                        <ul style="margin:0 0 0 -30px;">
                          <li>Process Validation</li>
                          <li>Analytical validation</li>
                          <li>Cleaning validation&nbsp; </li>
                        </ul>
                      </li>
                      <li>Protocols for DQ, IQ, PQ and OQ for equipments </li>
                      <li>Other GMP documents </li>
                      <li>Review of documents and approvals from  regulatory agencies to identify gaps and non compliances</li>
                    </ul>
                  </div>
                </dd>
                <!-- //.acc-body -->
                <dt class="acc-head"> <a href="#">Audits</a> </dt>
                <dd class="acc-body">
                  <div class="content">
                    <p>We conduct    comprehensive audits as per &nbsp;the    requirements of GMP auditing, ISO, UK-MHRA, MCC, TGA, in house or other    standards as required by you.</p>
                      <p>We audit the    following segments</p>
                    <ul>
                      <li>API / Excipient / Packaging materials Vendor </li>
                      <li>Analytical and stability centres </li>
                      <li>Formulation and manufacturing sites</li>
                      <li>Clinical and preclinical study centres</li>
                    </ul>
                  </div>
                </dd>
                <!-- //.acc-body -->
                <dt class="acc-head"> <a href="#">Training</a> </dt>
                <dd class="acc-body">
                  <div class="content">
                    <ul>
                      <li>Imparting SOP training to different departments</li>
                      <li>Imparting GMP training to different departments </li>
                      <li>Imparting training to face national and international audits</li>
                    </ul>
                  </div>
                </dd>
              </dl>
              <!-- END ACCORDION WRAPPER-->
            </div>
            <div class="grid_2" style="border-left:1px solid #ccc; padding-left:20px;">
            <h3>Types of Services</h3>
              <h4>&raquo; <a href="services-regulatory.php">Regulatory Services</a></h4>
              <h4>&raquo; <a href="services-support.php">Support Services</a></h4></div></div>
        </div>
      </div>
      <!-- END CONTENT WRAPPER -->
    </div>
  </div>
  <!-- BEGIN FOOTER -->

<footer id="footer" class="footer">
  <div class="footer-holder">
    <div class="footer-frame">
      <!-- Copyright -->
      <div class="copyright">
        <div class="container clearfix">
          <div class="grid_12">
            <div class="clearfix">
              <div class="copyright-primary"> &copy;  Dossier Solutions & Services LLP</div>
              <div class="copyright-secondary"> Powered by <a href="http://www.surfzone-india.com" target="_blank">Surfzone Technologies</a> </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /Copyright -->
    </div>
  </div>
</footer>
<!-- END FOOTER -->
</div>
<!-- END WRAPPER -->
<!-- Javascript Files
	================================================== -->
<!-- initialize jQuery Library -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/jquery-1.9.1.min.js"><\/script>')</script>
<script src="js/jquery-migrate-1.1.1.min.js"></script>
<!-- Modernizr -->
<script src="js/modernizr.custom.17475.js"></script>
<!-- easing plugin -->
<script src="js/jquery.easing.min.js"></script>
<!-- Prettyphoto -->
<script src="js/jquery.prettyPhoto.js"></script>
<!-- Superfish -->
<script src="js/jquery.mobilemenu.js"></script>
<!-- superfish -->
<script src="js/jquery.superfish-1.5.0.js"></script>
<!-- Twitter -->
<script src="js/jquery.twitter.js"></script>
<!-- Flickr -->
<script src="js/jflickrfeed.js"></script>
<!-- ElastiSlide Carousel -->
<script src="js/jquery.elastislide.js"></script>
<!-- jQuery REVOLUTION Slider  -->
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<!-- Isotope -->
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<!-- Flexslider -->
<script src="js/jquery.flexslider.js"></script>
<!-- Custom -->
<script src="js/custom.js"></script>
</body></html>
