<!DOCTYPE html>
<!--[if IE 7]>                  <html class="ie7 no-js" lang="en">     <![endif]-->
<!--[if lte IE 8]>              <html class="ie8 no-js" lang="en">     <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html class="not-ie no-js" lang="en">
<!--<![endif]-->
<head>
<!-- Basic Page Needs
	================================================== -->
<meta charset="utf-8">
<title>About Us - Dossier Solutions and Services LLP</title>
<link rel="icon" href="images/logo1.png"><meta name="description" content="">
<meta name="description" content="">
<meta name="author" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<!-- Mobile Specific Metas
	================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!-- CSS
	================================================== -->
<!-- Normalize default styles -->
<link rel="stylesheet" href="css/normalize.css" media="screen" />
<!-- Skeleton grid system -->
<link rel="stylesheet" href="css/skeleton.css" media="screen" />
<!-- Base Template Styles-->
<link rel="stylesheet" href="css/base.css" media="screen" />
<!-- Template Styles-->
<link rel="stylesheet" href="css/style.css" media="screen" />
<!-- Superfish -->
<link rel="stylesheet" href="css/superfish.css" media="screen" />
<!-- Prettyphoto -->
<link rel="stylesheet" href="css/prettyPhoto.css" media="screen" />
<!-- FontAwesome -->
<link rel="stylesheet" href="css/font-awesome.min.css" media="screen" />
<!-- REVOLUTION BANNER CSS SETTINGS -->
<link rel="stylesheet" href="css/settings.css" media="screen" />
<!-- Flexslider -->
<link rel="stylesheet" href="css/flexslider.css" media="screen" />
<!-- Layout and Media queries-->
<link rel="stylesheet" href="css/media-queries.css" media="screen" />
<!--[if lt IE 9]>
		<link rel="stylesheet" href="css/ie/ie8.css" media="screen" />
	<![endif]-->
<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
<!-- Favicons
	================================================== -->
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/apple-touch-icon-144x144.png">
<script language="JavaScript">
<!--
function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
    } if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
} }

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<body>
<!-- BEGIN WRAPPER -->
<div id="wrapper">
<div class="wrapp-holder">
<div class="wrap-frame">
<!-- BEGIN HEADER -->
<header id="header" class="header">
  <!-- Top Header -->
  <div class="header-top">
    <div class="container clearfix">
      <div class="grid_12">
        <!-- Top Menu -->
        <ul class="header-top-menu unstyled">
          <span style="color:#ebebeb">Top notch solutions, delivered on time every time!!</span>
          <!--<li><a href="#">Pricing</a></li>
									<li><a href="#">Sitemap</a></li>
									<li><a href="#">FAQs</a></li>-->
        </ul>
        <!-- /Top Menu -->
        <!-- Social Links -->
        <ul class="social-links unstyled">
          <script type="text/javascript">

// Current Server Time script (SSI or PHP)- By JavaScriptKit.com (http://www.javascriptkit.com)
// For this and over 400+ free scripts, visit JavaScript Kit- http://www.javascriptkit.com/
// This notice must stay intact for use.

//Depending on whether your page supports SSI (.shtml) or PHP (.php), UNCOMMENT the line below your page supports and COMMENT the one it does not:
//Default is SSI method is uncommented:

//var currenttime = '<!--#config timefmt="%B %d, %Y %H:%M:%S"--><!--#echo var="DATE_LOCAL" -->' //SSI method of getting server date
//var currenttime = 'May 30, 2021 00:21:16' //PHP method of getting server date
var currenttime = 'May 30, 2021 00:21:16' //PHP method of getting server date

///////////Stop editting here/////////////////////////////////

var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
var serverdate=new Date(currenttime)

function padlength(what){
var output=(what.toString().length==1)? "0"+what : what
return output
}

function displaytime(){
serverdate.setSeconds(serverdate.getSeconds()+1)
var datestring=montharray[serverdate.getMonth()]+" "+padlength(serverdate.getDate())+", "+serverdate.getFullYear()
var timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())+":"+padlength(serverdate.getSeconds())
document.getElementById("servertime").innerHTML=datestring
}

window.onload=function(){
setInterval("displaytime()", 1000)
}


</script>
      <span id="servertime" style="color:#ebebeb"></span>
        </ul>
        <!-- /Social Links -->
      </div>
    </div>
  </div>
  <!-- /Top Header -->
  <!-- Main Header -->
  <div class="header-main">
    <div class="container clearfix">
      <div class="grid_12 hr-bottom">
        <!-- BEGIN LOGO -->
        <div id="logo">
          <!-- Image based Logo-->
          <a href="index.php"><img src="images/logo.png" alt="Dossier Solutions & Services LLP" width="325" /></a>
          <!-- Text based Logo
									<h1><a href="index.html">Emotion</a></h1>
									<p class="tagline">Responsive HTML Template</p>
									-->
        </div>
        <!-- END LOGO -->
        <!-- BEGIN NAVIGATION -->
        <nav class="primary">
          <ul class="sf-menu">
            <li > <a href="index.php">Home<!--<span><i>|</i> Get Started</span>--></a> </li>
            <li class="current-menu-item"> <a href="aboutus.php">About Us<!--<span><i>|</i> Why Choose Us</span>--></a></li>
            <li > <a href="services.php">Services<!--<span><i>|</i>Regulatory & Support</span>--></a>
            <!-- Sub Navigation -->
              <ul>
                <li><a href="services-regulatory.php">Regulatory Services</a></li>
                <li><a href="services-support.php">Support Services</a></li>
              </ul>
              <!-- /Sub Navigation -->
              </li>
               <li > <a href="team.php">Team<!--<span><i>|</i> Get in Touch</span>--></a>
            </li>
             <li > <a href="careers.php">Careers<!--<span><i>|</i> Get in Touch</span>--></a>
            </li>
             <li > <a href="enquiry.php">Enquiry<!--<span><i>|</i> Get in Touch</span>--></a>
            </li>
            <li > <a href="contactus.php">Contact<!--<span><i>|</i> Get in Touch</span>--></a>
            </li>
          </ul>
        </nav>
        <!-- END NAVIGATION -->
      </div>
    </div>
  </div>
  <!-- /Main Header -->
</header>
<!-- END HEADER -->
      <!-- BEGIN CONTENT WRAPPER -->
      <div id="content-wrapper" class="content-wrapper">
        <div class="container maincontent"> 
          <!-- BEGIN SLIDER -->
          <div id="slider" class="slider loading" style="height:150px; padding-top:15px;">
            <div class="container clearfix"> 
              <!--<div class="grid_12">-->
              <div class="bannercontainer" style="height:150px;">
                <div class="banner">
                  <ul>
                    <!-- THE SECOND SLIDE -->
                    <li data-transition="fade" data-slotamount="10" data-masterspeed="300" data-slideindex="back"> 
                      <!-- THE MAIN IMAGE IN THE SLIDE --> 
                      <img src="images/bg-02.jpg" style="margin-top:-130px;"> 
                      <!-- THE CAPTIONS OF THE SECOND SLIDE -->
                      <div class="tp-caption sfl original"
												data-x="50"
												data-y="25"
												data-speed="300"
												data-start="600"
												data-captionhidden="on"
												data-endeasing="easeOutExpo"
												data-easing="easeOutExpo"> Our team comprises of </div>
                      <div class="tp-caption sfr original_high"
												data-x="142"
												data-y="78"
												data-speed="300"
												data-start="800"
												data-captionhidden="on"
												data-endeasing="easeOutExpo"
												data-easing="easeOutExpo"> Experienced Professionals </div>
                    </li>
                  </ul>
                </div>
              </div>
              <!-- </div>--> 
            </div>
          </div>
          <!-- END SLIDER --> 
          <!-- BEGIN PAGE TITLE -->
          <div id="page-title" class="page-title"> 
            <!--<div class="container clearfix maincontent">-->
            <div class="grid_12">
              <div class="page-title-holder clearfix">
                <h1>OUR TEAM</h1>
              </div>
            </div>
            <!--</div>--> 
          </div>
          <!-- END PAGE TITLE -->
          <div class="clearfix">
            <div class="grid_9">
              <div class="team-holder clearfix">
                <div>
                  <h3>Mr. Suresh Khanna</h3>
                  <p>Engineer by education, Designated Partner, Dossier Solutions &amp; Services LLP.                  </p>
                  <p>Was founder Chairman of M/s.Stabicon Life Sciences Pvt. Ltd. a Contract Research &amp; Development Organization. He is a Business Advisor and Member of theBoards of a few companies in both India and abroad. He has contributed, as Executive Director, towards establishing KEMWELL, oneof the largest Contract Manufacturing Company in Bangalore. Has wide experience in areas of API's, Formulations, Diagnostics,Analytical equipment and Surgical. Also, was a Member of the Board of Millipore Pvt. Ltd. India, a JV company of Millipore CorporationUSA. Suresh has been a Past President of Karnataka Drugs &amp; Pharmaceuticals Manufacturer's Association (KDPMA) and IPA,Karnataka State Branch. HQ member of IPCA and currently the Hon. Secretary of the Indian Pharmaceutical Association (IPA). He isalso a Steering Committee Member of KDPMA, Chairman of Pharma Training Institute and Permanent Trustee of KarnatakaPharmaceutical Trust (KPT), a not for profit Organization, engaged to uplift Pharmacy Education in India.
                  </p>
                  <hr>
                  <h2>Regulatory Affairs</h2>
                  <h3>Dr. A. Rajani </h3>
                  <p>Pharma Regulatory professional , Post Graduate in Chemistry , Post Graduation Diploma in Pharmaceutical management
                    from IPER Pune 25+ Years experience in QA, Regulatory Affairs, QC, ASD &amp; TTD Department. Adept in compiling Dossiers in CTD                    Format for Regulated markets, handling of eCTD software and responding to Regulatory queries. Worked with major Indian and overseas                    Pharma Companies like MERCK, Strides, BPRL, Star Drugs , and currently Dossier Solutions &amp; Services LLP. Expertise in Regulatory                    matters, leading administrative, operational, business promotion and development projects
                  </p>
                  <h3>Ms. Vanishree</h3>
                  <p>M.Pharm with 14+Years of experience in Regulatory affairs and quality Assurance (Formulation) in Pharmaceutical                    industry. Compilation of CMC part of EU-CTD and other abbreviated dossiers for International Markets. Well-versed working with XML,                    the backbone of CTD. Managing regulatory submission and approval process, also assuring complete and timely response to the                    Regulatory Agencies during application review. Coordinating during all the regulatory audits and customer visits and supporting for                    compliance activities. Worked with major Indian and international Pharma Companies like All India Tablet industry, Micro Labs Ltd, Oman                    Pharmaceutical products Co LLC, Oman and currently Dossier Solutions &amp; Services LLP.</p>
                  <h3>Ms. Renu Koul</h3>
                  <p>Post graduate in Pharmacy with over 20 years extensive experience in the area of visualising and designing of promotional materials for healthcare industries. Development of packaging materials. Worked in Ranbaxy.</p>
                  <p>&nbsp;</p>
                  <hr>
                  <h2>Quality Management Services (QMS)</h2>
                  <h3> Mr. Goutam S Saha</h3>
                  <p>Veteran in Pharmaceutical, Biologics and Medical devices Quality domains. Bangalore based consultant. Topper in M. Sc. (Organic Chemistry); 
                    PG Research as JRF on medicinal plants, UGC project; Certificate course in Clinical Trial Management from ICRI, Bombay. Started career in R&amp;D and Quality. Sailed
                    around India &amp; Aboard over 27 years. Nurtured in Hoechst, Pfizer, Lupin, Ranbaxy, Universal, Sentiss, Strides, Agila, Cipla BT. Leaded audit management for USFDA,
                    MHRA, TGA, MCC, WHO, PICs, ANVIZA, etc. Highly skilled, result oriented accomplished team leader in design, C&amp;Q, reverse engineering of Greenfield projects for
                  potent drugs involving Platform technology and ASTM 2500E risk based approach. </p>
                  <p>Expertise in QMS of NCE, Sterile, OSD, r-DNA, Bio-similar, Stem-cell, in facilitating
                    Process validation, Cleaning validation, Operational excellence and Quality culture. Investigated 1000 of OOS, OOT, failure RC, and data integrity breach (ALCOA) and
                    implemented CAPA and strategic remediation to import alert. Established GMP Trainer and Coach as per ICH, EudraLex, CFR and aseptic practices, behavioural GMP,
                    ALCOA, computer system validation with proven track in India, Kenya and China. Supplier audit : Anthem Bioscience, Eurofins Advinus, Gland Chemical, GVK, Sai Life
                    Science, Vindhya Organics, Bajaj Life Science, Pharbaco JSC (Vietnam), MoH Myanmar, Hisun Pharma, Biomab Shanghai. Comprehensive assessment of
                    productivity - GSK-CBPVL Rabies vaccine and Cipla corporate quality function on behalf of McKinsey INC. Strategic remediation for Torrent, Syngene (Biocon),
                    Apotex, Hetero and Malladi as collaborative effort with QCG. </p>
                  <p>Facilitated USFDA, PIC/S, ANVIZA, INVIMA, GCC, EMEA audit and certification for Aurigene (DRL),
                    Wockhardt, Wintac, Aizant, Unichem, Virchow, Evertogen.</p>
                  <h3>Mr. Harish Babu M.L </h3>
                  <p>M Pharm Pharmaceutics. High-energy, focused senior Corporate Quality/R&amp;D professional with 21 years of overall experience in Global
                    Quality, Process Development &amp; Technology Transfer, Clinical research associate, Technical Services, Contract Manufacturing operations &amp; R&amp;D Project management
                    in Pharmaceutical industry. Successfully completed Executive general management program from IIM Bangalore. Proficient in performing Global Quality Audits &amp; Due
                    diligence- completed about 220 audits. BA/BE study Monitoring : Monitored as CRA/Sponsor representative about 40 BA/BE studies – US &amp; EU markets at different
                    CRO locations. Having rich exposure: Quality Assurance &amp; Product transfer/Scale up exposure – transferred from R&amp;D to plant transfers &amp; International exposure:
                    worked as Project lead- transferred about 25 Sterile products from India to Strides Poland facility and established the technology transfer procedures in the new Sterile
                  facility at Poland. </p>
                  <p>Active participation in successful regulatory audits by MHRA, TGA, MCC, ANVISA, WHO, USFDA &amp; other customer audits and extensive support
                    during USFDA audits in different units - handled different dosage forms such as Parenterals, Solid Orals, Pelletization technologies, Compaction processes, Dry
                  powders, Liquids &amp; Ointments.</p>
                  <h3>Ms. Matilda George </h3>
                  <p>M.Sc. in Organic Chemistry from Vikram University, Ujjain in 1985. Offering chronicled success of nearly 30 years in spearheading Quality
                    Operations in Pharmaceutical industry (QC/QA). A strategist &amp; implementer with track record of establishing Quality &amp; reliable standards. Expertise in designing and
                    setting up of Quality Control Laboratories (Chemical &amp; Microbiology). Training, Qualification and building up of Quality Talent resources for Laboratory analysis.
                    Extensive expertise in planning and organizing the Regulatory and client audits and dealing with Investigation management. Led the Site Quality control team for the
                    Remediation project and related activities and further coordination with international quality experts. Worked on 21 CFR Part 11 &amp; Data Integrity compliance in Quality
                  Operations. Data compilation &amp; Stability management.</p>
                  <h3>Dr. Prakash Deshpande</h3>
                  <p>PhD in Analytical chemistry  with over 40 years of experience in Quality Control QA and Regulatory Dossier  compilation. Worked in Public Testing laboratory and domestic Pharmaceutical  companies ( Alkem)</p>
                  <p>&nbsp;</p>
                  <h3>Ms. Smitha Rao</h3>
                  <p>Over 18 years' experience in Pharmaceutical Microbiology. Has worked as In-charge of Microbiology laboratory in MNC pharma company.
                  </p>
                  <hr>
                  <h2>EHS &amp; Engineering Management including Equipment And Process qualification / validation</h2>
                  <h3>Mr. B Karthik</h3>
                  <p>30+ years of proven years of leading and executing EHS (Environment, Health, Safety) best practices in Manufacturing
                    facilities, supply chain operations, office /Commercial environment and construction projects. Hands on knowledge on developing and
                  implementing customized business systems on lines of ISO management systems (9,14,45,51K) across multiple global locations. </p>
                  <p>Carried
                    out EHS programs (assessments/ audits / training / awareness session including electrical safety/fire safety), Process Safety Management
                    (PSM) Training &amp; implementation, Behavior Based Safety (BBS) implementation and IS 14489 plant assessments, in Chemical
                    Manufacturing facilities (including API facilities), Pharma Formulations, Oil &amp;Gas, Jewellery refining and Electroplating, amongst other
                  industries. </p>
                  <p>During his corporate career, got trained on 1) OSHA, CFR 1926, Construction Safety / Contractor Safety Management norms for
                    projects, at St. Louis, MO, USA. 2) Chemical Process Safety Management Expertise at Basle, Switzerland. 3) Behavior Safety training at
                    Melbourne, Australia. Trained as ISO Auditor (@ Perry Johnson) for Integrated ISO systems implementation as well as for conducting
                    corporate international EHS audits, at Morristown, NJ, USA. Masters in Environmental engineering by qualification as first batch pass out in
                    India, (1985) as well as Safety professional by diploma offered by Govt. of Gujarat, (1990). Certified Lean expert through Green Belt training
                    and project execution. Passed out MBA in HR to link people perspective to EHS. </p>
                  <p>Has professional experience with companies such as
                    Monsanto (Bangalore), Sandoz (Ankleshwar), Astra Zeneca (Bangalore) and BASF (Mangalore)</p>
                  <h3>Mr. Maneesh Merwade </h3>
                  <p>Pharma 11 years of experience in equipment and process qualification/validation, troubleshooting to support
                    operations, engineering upgrades, process scale-up and ramp-up. Held different positions in an engineering role at global pharma
                    organizations such as Genentech (California), Boehringer Ingelheim (Ohio), Pfizer (New York)                  </p>
                  <p>Hands-on working experience with processing systems and utilities from processing skids, downstream processing equipment, aseptic filling,
                    packaging &amp; inspection and plant utilities–their
                    engineering,installation, operation, commissioning and qualification. (over 25 projects Approx value 50 million USD)                  </p>
                  <p>Expertise in cleaning, sterilization and equipment qualification (IQ, OQ, PQ, CV etc.) as per 21 CFR Part 210, 211 for Pharmaceutical &amp;
                    Biopharma facilities..Maintainence of the validated state ensuring compliance for GMP environment.                  </p>
                  <p>Facility and Engineered Systems design, installation, commissioning, qualification and operation for Pharma &amp; Biopharma to optimize
                    throughput while meeting compliance requirements.</p>
                  <p>Provided expert guidance in cGMP, regulatory compliance, Consent decree remediation, Manufacturing process, equipment and facility<br>
                  investigations, remediation of observations by regulatory authorities.</p>
                  <h3>Mr. H.A.Nagabhushana </h3>
                  <p>B.E.(mechanical) Bangalore University, Having 20 years of professional experience in                    pharmaceutical engineering, through projects and plant engineering out of which 10 years in sterile plants as Head -Engineering. Worked                    for GSK, Anglo French, Wintac Ltd and Aurobindo pharma, etc. Have faced multiple international audit, including USFDA audits</p>
                </div>
              </div>
            </div>
          <div class="grid_2" style="border-left:1px solid #ccc; padding-left:20px;">
            <h3>Types of Services</h3>
            <h4>&raquo; <a href="services-regulatory.php">Regulatory Services</a></h4>
            <h4>&raquo; <a href="services-support.php">Support Services</a></h4>
          </div>
        </div>
      </div>
    </div>
    <!-- END CONTENT WRAPPER --> 
  </div>
</div>
<!-- BEGIN FOOTER -->

<footer id="footer" class="footer">
  <div class="footer-holder">
    <div class="footer-frame">
      <!-- Copyright -->
      <div class="copyright">
        <div class="container clearfix">
          <div class="grid_12">
            <div class="clearfix">
              <div class="copyright-primary"> &copy;  Dossier Solutions & Services LLP</div>
              <div class="copyright-secondary"> Powered by <a href="http://www.surfzone-india.com" target="_blank">Surfzone Technologies</a> </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /Copyright -->
    </div>
  </div>
</footer>
<!-- END FOOTER -->
</div>
<!-- END WRAPPER -->
<!-- Javascript Files
	================================================== -->
<!-- initialize jQuery Library -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/jquery-1.9.1.min.js"><\/script>')</script>
<script src="js/jquery-migrate-1.1.1.min.js"></script>
<!-- Modernizr -->
<script src="js/modernizr.custom.17475.js"></script>
<!-- easing plugin -->
<script src="js/jquery.easing.min.js"></script>
<!-- Prettyphoto -->
<script src="js/jquery.prettyPhoto.js"></script>
<!-- Superfish -->
<script src="js/jquery.mobilemenu.js"></script>
<!-- superfish -->
<script src="js/jquery.superfish-1.5.0.js"></script>
<!-- Twitter -->
<script src="js/jquery.twitter.js"></script>
<!-- Flickr -->
<script src="js/jflickrfeed.js"></script>
<!-- ElastiSlide Carousel -->
<script src="js/jquery.elastislide.js"></script>
<!-- jQuery REVOLUTION Slider  -->
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<!-- Isotope -->
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<!-- Flexslider -->
<script src="js/jquery.flexslider.js"></script>
<!-- Custom -->
<script src="js/custom.js"></script>
</body></html>
